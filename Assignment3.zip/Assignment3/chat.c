#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

#define MAX_STATES 100
#define MAX_ALPHABET 26
#define TRANSITION 1
#define QUIT 2

/* Global variables */
int s;  /* Alphabet size */
int n;  /* Number of states */
int pipes[MAX_STATES + 1][2];  /* pipes[0] for coordinator, pipes[1..n] for states */
int original_stdin, original_stdout;

/* Data structure for each state */
typedef struct {
    int is_final;
    int delta[MAX_ALPHABET];
} StateInfo;

StateInfo states[MAX_STATES];

/* Signal handler for coordinator */
void windup_handler(int signo) {
    int i;
    
#ifdef _VERBOSE
    printf("\n +++ Coordinator going to terminate all state processes\n");
    fflush(stdout);
#endif
    
    /* Send QUIT command to all state processes */
    for (i = 0; i < n; i++) {
        dup2(pipes[i + 1][1], STDOUT_FILENO);
        printf("%d\n", QUIT);
        fflush(stdout);
    }
    
    /* Restore stdout */
    dup2(original_stdout, STDOUT_FILENO);
    
    /* Wait for all children to terminate */
    for (i = 0; i < n; i++) {
        wait(NULL);
    }
    
#ifndef _VERBOSE
    printf(" +++ Coordinator: All state processes terminated. Bye.\n");
#else
    printf(" +++ Coordinator: Bye\n");
#endif
    fflush(stdout);
    
    exit(0);
}

/* State process loop */
void state_loop(int state_num) {
    int command, next_state;
    char symbol;
    int is_final;
    int delta[MAX_ALPHABET];
    int i;
    
    /* Ignore SIGINT */
    signal(SIGINT, SIG_IGN);
    
    /* Read state information from coordinator */
    dup2(pipes[state_num + 1][0], STDIN_FILENO);
    scanf("%d", &is_final);
    for (i = 0; i < s; i++) {
        scanf("%d", &delta[i]);
    }
    
    while (1) {
        /* Read command from own pipe */
        dup2(pipes[state_num + 1][0], STDIN_FILENO);
        if (scanf("%d", &command) != 1) {
            continue;
        }
        
        if (command == QUIT) {
#ifdef _VERBOSE
            dup2(original_stdout, STDOUT_FILENO);
            printf(" +++ State %d going to quit\n", state_num);
            fflush(stdout);
#endif
            exit(0);
        }
        
        if (command == TRANSITION) {
            /* Send current state number to coordinator */
            dup2(pipes[0][1], STDOUT_FILENO);
            printf("%d\n", state_num);
            fflush(stdout);
            
            /* Read next symbol from coordinator */
            dup2(pipes[state_num + 1][0], STDIN_FILENO);
            scanf(" %c", &symbol);
            
            /* Check if it's end-of-input marker */
            if (symbol == '$') {
                dup2(original_stdout, STDOUT_FILENO);
                if (is_final) {
                    printf(" ACCEPT\n");
                } else {
                    printf(" REJECT\n");
                }
                fflush(stdout);
                continue;
            }
            
            /* Check if symbol is valid */
            int symbol_idx = symbol - 'a';
            if (symbol_idx < 0 || symbol_idx >= s) {
                dup2(original_stdout, STDOUT_FILENO);
                printf(" INVALID INPUT SYMBOL: %c\n", symbol);
                fflush(stdout);
                continue;
            }
            
            /* Valid symbol - perform transition */
            next_state = delta[symbol_idx];
            
            /* Print transition */
            dup2(original_stdout, STDOUT_FILENO);
            printf(" -- %c --> %d", symbol, next_state);
            fflush(stdout);
            
            /* Send TRANSITION command to next state */
            dup2(pipes[next_state + 1][1], STDOUT_FILENO);
            printf("%d\n", TRANSITION);
            fflush(stdout);
        }
    }
}

/* User loop for coordinator */
void user_loop() {
    char input[10000];
    int i, current_state;
    int invalid_input;
    
#ifdef _VERBOSE
    printf(" +++ Coordinator: Going to user loop\n");
    fflush(stdout);
#endif
    
    while (1) {
        /* Read input string from user */
        dup2(original_stdin, STDIN_FILENO);
        dup2(original_stdout, STDOUT_FILENO);
        printf("Enter next string: ");
        fflush(stdout);
        
        if (fgets(input, sizeof(input), stdin) == NULL) {
            break;
        }
        
        /* Remove newline */
        input[strcspn(input, "\n")] = 0;
        
        /* Print initial state */
        printf("%d", 0);
        fflush(stdout);
        
        /* Send TRANSITION command to state 0 */
        dup2(pipes[1][1], STDOUT_FILENO);
        printf("%d\n", TRANSITION);
        fflush(stdout);
        
        invalid_input = 0;
        
        /* Process each symbol in input string */
        for (i = 0; input[i] != '\0' && !invalid_input; i++) {
            /* Read current state from coordinator pipe */
            dup2(pipes[0][0], STDIN_FILENO);
            scanf("%d", &current_state);
            
            /* Send symbol to current state */
            dup2(pipes[current_state + 1][1], STDOUT_FILENO);
            printf("%c\n", input[i]);
            fflush(stdout);
            
            /* Check if this might be an invalid symbol */
            int symbol_idx = input[i] - 'a';
            if (symbol_idx < 0 || symbol_idx >= s) {
                invalid_input = 1;
            }
        }
        
        if (!invalid_input) {
            /* Send end-of-input marker */
            dup2(pipes[0][0], STDIN_FILENO);
            scanf("%d", &current_state);
            
            dup2(pipes[current_state + 1][1], STDOUT_FILENO);
            printf("$\n");
            fflush(stdout);
        }
        
        /* Restore stdout for next iteration */
        dup2(original_stdout, STDOUT_FILENO);
        printf("\n");
        fflush(stdout);
    }
}

int main(int argc, char *argv[]) {
    char *filename;
    FILE *fp;
    int i, j, state_num;
    char final_marker;
    pid_t pid;
    
    /* Parse command line arguments */
    if (argc == 1) {
        filename = "dfa.txt";
    } else {
        filename = argv[1];
    }
    
    /* Save original stdin and stdout */
    original_stdin = dup(STDIN_FILENO);
    original_stdout = dup(STDOUT_FILENO);
    
    /* Read DFA from file */
    fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Error: Cannot open file %s\n", filename);
        exit(1);
    }
    
    fscanf(fp, "%d", &s);
    fscanf(fp, "%d", &n);
    
    for (i = 0; i < n; i++) {
        fscanf(fp, "%d %c", &state_num, &final_marker);
        states[state_num].is_final = (final_marker == 'F') ? 1 : 0;
        for (j = 0; j < s; j++) {
            fscanf(fp, "%d", &states[state_num].delta[j]);
        }
    }
    
    fclose(fp);
    
    /* Create pipes */
    for (i = 0; i <= n; i++) {
        if (pipe(pipes[i]) == -1) {
            perror("pipe");
            exit(1);
        }
    }
    
    /* Fork state processes */
    for (i = 0; i < n; i++) {
        pid = fork();
        
        if (pid == -1) {
            perror("fork");
            exit(1);
        }
        
        if (pid == 0) {
            /* Child process - state i */
            state_loop(i);
            exit(0);  /* Should never reach here */
        }
    }
    
    /* Parent (coordinator) process */
    sleep(1);  /* Wait for children to initialize */
    
    /* Send initial information to each state process */
    for (i = 0; i < n; i++) {
        dup2(pipes[i + 1][1], STDOUT_FILENO);
        printf("%d\n", states[i].is_final);
        for (j = 0; j < s; j++) {
            printf("%d ", states[i].delta[j]);
        }
        printf("\n");
        fflush(stdout);
        
#ifdef _VERBOSE
        dup2(original_stdout, STDOUT_FILENO);
        if (states[i].is_final) {
            printf(" +++ Final state %d created\n", i);
        } else {
            printf(" +++ Non-final state %d created\n", i);
        }
        fflush(stdout);
#endif
    }
    
    dup2(original_stdout, STDOUT_FILENO);
    printf(" +++ Coordinator: %d state processes are created\n", n);
    fflush(stdout);
    
    /* Register signal handler */
    signal(SIGINT, windup_handler);
    
    /* Enter user loop */
    user_loop();
    
    /* Normal termination (if user loop exits normally) */
    windup_handler(SIGINT);
    
    return 0;
}